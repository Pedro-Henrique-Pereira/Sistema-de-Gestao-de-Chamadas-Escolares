-- Restringe a preferência de máquinas do painel de mensagens do administrador.
-- Mensagens em grupos do Admin devem usar somente as máquinas 3, 4 e 5.

UPDATE usuarios
   SET maquina_padrao_mensagens = 3
 WHERE maquina_padrao_mensagens IS NOT NULL
   AND maquina_padrao_mensagens NOT IN (3, 4, 5);

-- Opcional: execute apenas uma vez se desejar reforço no banco.
-- Se já existir constraint equivalente, ignore o erro de constraint duplicada.
ALTER TABLE usuarios
  ADD CONSTRAINT chk_usuarios_maquina_padrao_mensagens_admin
  CHECK (maquina_padrao_mensagens IS NULL OR maquina_padrao_mensagens IN (3, 4, 5));
