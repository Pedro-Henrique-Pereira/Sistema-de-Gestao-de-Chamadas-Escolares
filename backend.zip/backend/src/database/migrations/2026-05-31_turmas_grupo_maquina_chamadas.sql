USE Sistema_Chamada;

-- Edição de turmas + grupo escolar sanitizado + preferência de máquina por pedagoga.
-- Idempotente: seguro para executar mais de uma vez.

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE turmas ADD COLUMN grupo_escolar VARCHAR(100) NULL AFTER nome',
    'SELECT "turmas.grupo_escolar já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'turmas'
    AND COLUMN_NAME = 'grupo_escolar'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE turmas ADD INDEX idx_turmas_grupo_escolar (grupo_escolar)',
    'SELECT "idx_turmas_grupo_escolar já existe"'
  )
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'turmas'
    AND INDEX_NAME = 'idx_turmas_grupo_escolar'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE usuarios ADD COLUMN maquina_padrao_chamadas TINYINT NULL AFTER ativo',
    'SELECT "usuarios.maquina_padrao_chamadas já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'usuarios'
    AND COLUMN_NAME = 'maquina_padrao_chamadas'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @old_safe_updates = @@SQL_SAFE_UPDATES;
SET SQL_SAFE_UPDATES = 0;
UPDATE usuarios
SET maquina_padrao_chamadas = NULL
WHERE maquina_padrao_chamadas IS NOT NULL
  AND maquina_padrao_chamadas NOT IN (1, 2);
SET SQL_SAFE_UPDATES = @old_safe_updates;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE usuarios ADD CONSTRAINT chk_usuarios_maquina_padrao_chamadas CHECK (maquina_padrao_chamadas IS NULL OR maquina_padrao_chamadas IN (1, 2))',
    'SELECT "chk_usuarios_maquina_padrao_chamadas já existe"'
  )
  FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = DATABASE()
    AND TABLE_NAME = 'usuarios'
    AND CONSTRAINT_NAME = 'chk_usuarios_maquina_padrao_chamadas'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE fila_automacao
  MODIFY status ENUM('pendente', 'executando', 'concluido', 'erro', 'expirado', 'cancelado') NOT NULL DEFAULT 'pendente';

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN tipo_automacao ENUM(''faltas'', ''mensagem_grupo'') NOT NULL DEFAULT ''faltas'' AFTER maquina_destino',
    'SELECT "fila_automacao.tipo_automacao já existe"')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fila_automacao' AND COLUMN_NAME = 'tipo_automacao'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN mensagem TEXT NULL AFTER grupo_escolar',
    'SELECT "fila_automacao.mensagem já existe"')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fila_automacao' AND COLUMN_NAME = 'mensagem'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN payload JSON NULL AFTER mensagem',
    'SELECT "fila_automacao.payload já existe"')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fila_automacao' AND COLUMN_NAME = 'payload'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
