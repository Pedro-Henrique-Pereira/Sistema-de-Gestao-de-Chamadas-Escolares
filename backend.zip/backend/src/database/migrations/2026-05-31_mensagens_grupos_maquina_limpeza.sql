USE Sistema_Chamada;

-- ============================================================
-- MENSAGENS POR GRUPOS ESCOLARES + PERSISTÊNCIA DE MÁQUINA
-- + LIMPEZA AUTOMÁTICA DE TAREFAS ANTIGAS
-- Idempotente: seguro para executar mais de uma vez.
-- ============================================================


-- Base segura da fila para máquinas 1 a 5.
CREATE TABLE IF NOT EXISTS fila_automacao (
  id INT AUTO_INCREMENT PRIMARY KEY,
  status ENUM('pendente', 'executando', 'concluido', 'erro', 'expirado', 'cancelado') NOT NULL DEFAULT 'pendente',
  data_solicitacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_fila_automacao_status_data (status, data_solicitacao)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE fila_automacao
  MODIFY status ENUM('pendente', 'executando', 'concluido', 'erro', 'expirado', 'cancelado') NOT NULL DEFAULT 'pendente';

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN usuario_solicitante_id INT NULL AFTER id',
    'SELECT "usuario_solicitante_id já existe"')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fila_automacao' AND COLUMN_NAME = 'usuario_solicitante_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN usuario_solicitante_nome VARCHAR(100) NULL AFTER usuario_solicitante_id',
    'SELECT "usuario_solicitante_nome já existe"')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fila_automacao' AND COLUMN_NAME = 'usuario_solicitante_nome'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN maquina_destino TINYINT NOT NULL DEFAULT 1 AFTER usuario_solicitante_nome',
    'SELECT "maquina_destino já existe"')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fila_automacao' AND COLUMN_NAME = 'maquina_destino'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN lock_owner VARCHAR(100) NULL AFTER status',
    'SELECT "lock_owner já existe"')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fila_automacao' AND COLUMN_NAME = 'lock_owner'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN lock_adquirido_em DATETIME NULL AFTER lock_owner',
    'SELECT "lock_adquirido_em já existe"')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fila_automacao' AND COLUMN_NAME = 'lock_adquirido_em'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN iniciado_em DATETIME NULL AFTER data_solicitacao',
    'SELECT "iniciado_em já existe"')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fila_automacao' AND COLUMN_NAME = 'iniciado_em'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN concluido_em DATETIME NULL AFTER iniciado_em',
    'SELECT "concluido_em já existe"')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fila_automacao' AND COLUMN_NAME = 'concluido_em'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN tentativas INT NOT NULL DEFAULT 0 AFTER concluido_em',
    'SELECT "tentativas já existe"')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fila_automacao' AND COLUMN_NAME = 'tentativas'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN erro TEXT NULL AFTER tentativas',
    'SELECT "erro já existe"')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fila_automacao' AND COLUMN_NAME = 'erro'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @old_safe_updates = @@SQL_SAFE_UPDATES;
SET SQL_SAFE_UPDATES = 0;
UPDATE fila_automacao SET maquina_destino = 1 WHERE maquina_destino IS NULL OR maquina_destino NOT BETWEEN 1 AND 5;
SET SQL_SAFE_UPDATES = @old_safe_updates;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD INDEX idx_fila_captura_segura (status, maquina_destino, data_solicitacao)',
    'SELECT "idx_fila_captura_segura já existe"')
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fila_automacao' AND INDEX_NAME = 'idx_fila_captura_segura'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 1) Turmas: grupo escolar opcional, usado diretamente pelo nome.
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE turmas ADD COLUMN grupo_escolar VARCHAR(100) NULL AFTER nome',
    'SELECT "coluna grupo_escolar já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'turmas'
    AND COLUMN_NAME = 'grupo_escolar'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE turmas ADD INDEX idx_turmas_grupo_escolar (grupo_escolar)',
    'SELECT "idx_turmas_grupo_escolar já existe"'
  )
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'turmas'
    AND INDEX_NAME = 'idx_turmas_grupo_escolar'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 2) Usuários: máquina padrão por conta para a tela Mensagens.
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE usuarios ADD COLUMN maquina_padrao_mensagens TINYINT NULL AFTER ativo',
    'SELECT "maquina_padrao_mensagens já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'usuarios'
    AND COLUMN_NAME = 'maquina_padrao_mensagens'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 3) Fila: campos de tipo e payload para mensagem por grupo.
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN tipo_automacao ENUM(''faltas'', ''mensagem_grupo'') NOT NULL DEFAULT ''faltas'' AFTER maquina_destino',
    'SELECT "tipo_automacao já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'tipo_automacao'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN grupo_escolar VARCHAR(100) NULL AFTER tipo_automacao',
    'SELECT "grupo_escolar em fila_automacao já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'grupo_escolar'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN mensagem TEXT NULL AFTER grupo_escolar',
    'SELECT "mensagem em fila_automacao já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'mensagem'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN payload JSON NULL AFTER mensagem',
    'SELECT "payload em fila_automacao já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'payload'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD INDEX idx_fila_mensagens_grupo (tipo_automacao, status, maquina_destino, data_solicitacao)',
    'SELECT "idx_fila_mensagens_grupo já existe"'
  )
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND INDEX_NAME = 'idx_fila_mensagens_grupo'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 4) Limpeza automática de tarefas antigas.
-- Eventos do MySQL precisam do event_scheduler habilitado:
-- SET GLOBAL event_scheduler = ON;
DROP EVENT IF EXISTS ev_limpeza_fila_automacao_antiga;
DELIMITER $$
CREATE EVENT ev_limpeza_fila_automacao_antiga
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP + INTERVAL 1 HOUR
DO
BEGIN
  DELETE FROM fila_automacao
  WHERE status IN ('concluido', 'erro', 'expirado')
    AND data_solicitacao < DATE_SUB(NOW(), INTERVAL 30 DAY);

  UPDATE fila_automacao
  SET status = 'expirado',
      erro = COALESCE(erro, 'Tarefa expirada automaticamente por ficar pendente por mais de 7 dias.')
  WHERE status = 'pendente'
    AND data_solicitacao < DATE_SUB(NOW(), INTERVAL 7 DAY);

  UPDATE fila_automacao
  SET status = 'pendente',
      lock_owner = NULL,
      lock_adquirido_em = NULL,
      iniciado_em = NULL,
      erro = COALESCE(erro, 'Lock liberado automaticamente por inatividade superior a 30 minutos.')
  WHERE status = 'executando'
    AND lock_adquirido_em < DATE_SUB(NOW(), INTERVAL 30 MINUTE);
END$$
DELIMITER ;

-- Conferência rápida.
SELECT id, nome, grupo_escolar FROM turmas ORDER BY nome ASC;
