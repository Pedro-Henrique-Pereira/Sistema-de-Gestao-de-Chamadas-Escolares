-- Migração P0: rastreamento server-side de sessões JWT por jti.
-- Execute esta migração antes de subir o backend corrigido.

CREATE TABLE IF NOT EXISTS sessoes_ativas (
  id CHAR(36) NOT NULL,
  usuario_id INT NOT NULL,
  token_id CHAR(36) NOT NULL,
  dispositivo_info TEXT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expira_em DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_sessoes_ativas_token_id (token_id),
  KEY idx_sessoes_ativas_usuario_token (usuario_id, token_id),
  KEY idx_sessoes_ativas_expira_em (expira_em),
  CONSTRAINT fk_sessoes_ativas_usuario
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Limpeza segura de sessões antigas/expiradas, se existirem.
DELETE FROM sessoes_ativas WHERE expira_em <= NOW();
