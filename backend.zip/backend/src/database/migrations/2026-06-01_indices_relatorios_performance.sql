USE Sistema_Chamada;

-- Índices estruturais para relatórios rápidos.
-- Migração idempotente: segura para executar mais de uma vez.

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE registros_frequencia_alunos ADD INDEX idx_rfa_data_registro (data_chamada, registro_chamada_id)',
    'SELECT "idx_rfa_data_registro já existe"')
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'registros_frequencia_alunos'
    AND INDEX_NAME = 'idx_rfa_data_registro'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE registros_frequencia_alunos ADD INDEX idx_rfa_turma_data (turma_id, data_chamada)',
    'SELECT "idx_rfa_turma_data já existe"')
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'registros_frequencia_alunos'
    AND INDEX_NAME = 'idx_rfa_turma_data'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE registros_frequencia_alunos ADD INDEX idx_rfa_aluno_data (aluno_id, data_chamada)',
    'SELECT "idx_rfa_aluno_data já existe"')
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'registros_frequencia_alunos'
    AND INDEX_NAME = 'idx_rfa_aluno_data'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE justificativas_frequencia ADD INDEX idx_jf_aluno_freq (aluno_id, frequencia_aluno_id)',
    'SELECT "idx_jf_aluno_freq já existe"')
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'justificativas_frequencia'
    AND INDEX_NAME = 'idx_jf_aluno_freq'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE registros_chamadas_confirmadas ADD INDEX idx_rcc_turma_data (turma_id, data_chamada)',
    'SELECT "idx_rcc_turma_data já existe"')
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'registros_chamadas_confirmadas'
    AND INDEX_NAME = 'idx_rcc_turma_data'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
