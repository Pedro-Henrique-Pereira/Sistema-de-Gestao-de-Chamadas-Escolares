USE Sistema_Chamada;

-- ============================================================
-- MIGRAÇÃO SEGURA: Grupos Escolares + Mensagens da Administração
-- Escopo deste arquivo:
--   1) Adiciona grupo_escolar opcional em turmas.
--   2) Adiciona preferência de máquina por conta em usuarios.
--   3) Expande fila_automacao para mensagens personalizadas por grupo.
--   4) Adiciona índices para evitar lentidão.
--   5) Cria limpeza automática de tarefas antigas da fila.
--
-- Observação:
--   Este arquivo NÃO cria código de frontend, backend nem automação Python.
--   Ele prepara somente o banco de dados para a funcionalidade.
-- ============================================================

-- ============================================================
-- 1) TURMAS: grupo_escolar opcional
-- ============================================================

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE turmas ADD COLUMN grupo_escolar VARCHAR(100) NULL AFTER nome',
    'SELECT "coluna turmas.grupo_escolar já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'turmas'
    AND COLUMN_NAME = 'grupo_escolar'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE turmas ADD INDEX idx_turmas_grupo_escolar (grupo_escolar)',
    'SELECT "índice idx_turmas_grupo_escolar já existe"'
  )
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'turmas'
    AND INDEX_NAME = 'idx_turmas_grupo_escolar'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================================
-- 2) USUÁRIOS: máquina padrão para mensagens por conta
-- ============================================================

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE usuarios ADD COLUMN maquina_padrao_mensagens TINYINT NULL AFTER ativo',
    'SELECT "coluna usuarios.maquina_padrao_mensagens já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'usuarios'
    AND COLUMN_NAME = 'maquina_padrao_mensagens'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Normaliza valores inválidos, caso algum teste tenha inserido dados fora da faixa.
SET @old_safe_updates = @@SQL_SAFE_UPDATES;
SET SQL_SAFE_UPDATES = 0;

UPDATE usuarios
   SET maquina_padrao_mensagens = NULL
 WHERE maquina_padrao_mensagens IS NOT NULL
   AND maquina_padrao_mensagens NOT BETWEEN 1 AND 5;

SET SQL_SAFE_UPDATES = @old_safe_updates;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE usuarios ADD INDEX idx_usuarios_maquina_padrao_mensagens (maquina_padrao_mensagens)',
    'SELECT "índice idx_usuarios_maquina_padrao_mensagens já existe"'
  )
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'usuarios'
    AND INDEX_NAME = 'idx_usuarios_maquina_padrao_mensagens'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- CHECK opcional. Se o MySQL já tiver a constraint, não recria.
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE usuarios ADD CONSTRAINT chk_usuarios_maquina_padrao_mensagens CHECK (maquina_padrao_mensagens IS NULL OR maquina_padrao_mensagens BETWEEN 1 AND 5)',
    'SELECT "constraint chk_usuarios_maquina_padrao_mensagens já existe"'
  )
  FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = DATABASE()
    AND TABLE_NAME = 'usuarios'
    AND CONSTRAINT_NAME = 'chk_usuarios_maquina_padrao_mensagens'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================================
-- 3) FILA_AUTOMACAO: compatibilidade com fila antiga e nova
-- ============================================================

CREATE TABLE IF NOT EXISTS fila_automacao (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_solicitante_id INT NULL,
  usuario_solicitante_nome VARCHAR(100) NULL,
  maquina_destino TINYINT NOT NULL DEFAULT 1,
  tipo_automacao ENUM('faltas', 'mensagem_grupo') NOT NULL DEFAULT 'faltas',
  grupo_escolar VARCHAR(100) NULL,
  mensagem TEXT NULL,
  payload JSON NULL,
  status ENUM('pendente', 'executando', 'concluido', 'erro', 'expirado', 'cancelado') NOT NULL DEFAULT 'pendente',
  lock_owner VARCHAR(100) NULL,
  lock_adquirido_em DATETIME NULL,
  data_solicitacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  iniciado_em DATETIME NULL,
  concluido_em DATETIME NULL,
  tentativas INT NOT NULL DEFAULT 0,
  erro TEXT NULL,
  INDEX idx_fila_captura_segura (status, maquina_destino, data_solicitacao),
  INDEX idx_fila_tipo_status_maquina (tipo_automacao, status, maquina_destino, data_solicitacao),
  INDEX idx_fila_grupo_escolar (grupo_escolar),
  INDEX idx_fila_usuario (usuario_solicitante_id),
  INDEX idx_fila_lock (lock_owner, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE fila_automacao
  MODIFY status ENUM('pendente', 'executando', 'concluido', 'erro', 'expirado', 'cancelado')
  NOT NULL DEFAULT 'pendente';

-- usuario_solicitante_id
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN usuario_solicitante_id INT NULL AFTER id',
    'SELECT "fila_automacao.usuario_solicitante_id já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'usuario_solicitante_id'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- usuario_solicitante_nome
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN usuario_solicitante_nome VARCHAR(100) NULL AFTER usuario_solicitante_id',
    'SELECT "fila_automacao.usuario_solicitante_nome já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'usuario_solicitante_nome'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- maquina_destino
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN maquina_destino TINYINT NOT NULL DEFAULT 1 AFTER usuario_solicitante_nome',
    'SELECT "fila_automacao.maquina_destino já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'maquina_destino'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- tipo_automacao
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN tipo_automacao ENUM(''faltas'', ''mensagem_grupo'') NOT NULL DEFAULT ''faltas'' AFTER maquina_destino',
    'SELECT "fila_automacao.tipo_automacao já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'tipo_automacao'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Garante enum atualizado caso a coluna já existisse em versão anterior.
ALTER TABLE fila_automacao
  MODIFY tipo_automacao ENUM('faltas', 'mensagem_grupo') NOT NULL DEFAULT 'faltas';

-- grupo_escolar
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN grupo_escolar VARCHAR(100) NULL AFTER tipo_automacao',
    'SELECT "fila_automacao.grupo_escolar já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'grupo_escolar'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- mensagem
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN mensagem TEXT NULL AFTER grupo_escolar',
    'SELECT "fila_automacao.mensagem já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'mensagem'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- payload JSON para expansão futura sem novas alterações estruturais.
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN payload JSON NULL AFTER mensagem',
    'SELECT "fila_automacao.payload já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'payload'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- lock_owner
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN lock_owner VARCHAR(100) NULL AFTER status',
    'SELECT "fila_automacao.lock_owner já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'lock_owner'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- lock_adquirido_em
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN lock_adquirido_em DATETIME NULL AFTER lock_owner',
    'SELECT "fila_automacao.lock_adquirido_em já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'lock_adquirido_em'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- iniciado_em
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN iniciado_em DATETIME NULL AFTER data_solicitacao',
    'SELECT "fila_automacao.iniciado_em já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'iniciado_em'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- concluido_em
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN concluido_em DATETIME NULL AFTER iniciado_em',
    'SELECT "fila_automacao.concluido_em já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'concluido_em'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- tentativas
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN tentativas INT NOT NULL DEFAULT 0 AFTER concluido_em',
    'SELECT "fila_automacao.tentativas já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'tentativas'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- erro
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN erro TEXT NULL AFTER tentativas',
    'SELECT "fila_automacao.erro já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'erro'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Normaliza linhas antigas.
SET @old_safe_updates = @@SQL_SAFE_UPDATES;
SET SQL_SAFE_UPDATES = 0;

UPDATE fila_automacao
   SET maquina_destino = 1
 WHERE maquina_destino IS NULL
    OR maquina_destino NOT BETWEEN 1 AND 5;

UPDATE fila_automacao
   SET tipo_automacao = 'faltas'
 WHERE tipo_automacao IS NULL;

SET SQL_SAFE_UPDATES = @old_safe_updates;

-- Índices idempotentes da fila.
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD INDEX idx_fila_captura_segura (status, maquina_destino, data_solicitacao)',
    'SELECT "idx_fila_captura_segura já existe"'
  )
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND INDEX_NAME = 'idx_fila_captura_segura'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD INDEX idx_fila_tipo_status_maquina (tipo_automacao, status, maquina_destino, data_solicitacao)',
    'SELECT "idx_fila_tipo_status_maquina já existe"'
  )
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND INDEX_NAME = 'idx_fila_tipo_status_maquina'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD INDEX idx_fila_grupo_escolar (grupo_escolar)',
    'SELECT "idx_fila_grupo_escolar já existe"'
  )
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND INDEX_NAME = 'idx_fila_grupo_escolar'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD INDEX idx_fila_usuario (usuario_solicitante_id)',
    'SELECT "idx_fila_usuario já existe"'
  )
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND INDEX_NAME = 'idx_fila_usuario'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD INDEX idx_fila_lock (lock_owner, status)',
    'SELECT "idx_fila_lock já existe"'
  )
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND INDEX_NAME = 'idx_fila_lock'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- FK opcional com usuarios(id).
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD CONSTRAINT fk_fila_usuario_solicitante FOREIGN KEY (usuario_solicitante_id) REFERENCES usuarios(id) ON DELETE SET NULL',
    'SELECT "fk_fila_usuario_solicitante já existe"'
  )
  FROM INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND CONSTRAINT_NAME = 'fk_fila_usuario_solicitante'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================================
-- 4) LIMPEZA AUTOMÁTICA DE TAREFAS ANTIGAS
-- ============================================================
-- Regras adotadas:
--   - Tarefa executando travada há mais de 30 minutos volta para pendente.
--   - Tarefa pendente há mais de 7 dias vira expirada.
--   - Tarefa concluída/erro/expirada há mais de 30 dias é apagada.
--
-- Para o EVENT funcionar, o MySQL precisa estar com event_scheduler ativo:
--   SET GLOBAL event_scheduler = ON;
-- Em hospedagens gerenciadas, talvez seja necessário ativar isso no painel.
-- ============================================================

DROP PROCEDURE IF EXISTS sp_limpar_fila_automacao_antiga;

DELIMITER $$

CREATE PROCEDURE sp_limpar_fila_automacao_antiga()
BEGIN
  UPDATE fila_automacao
     SET status = 'pendente',
         lock_owner = NULL,
         lock_adquirido_em = NULL,
         iniciado_em = NULL,
         erro = CONCAT(
           COALESCE(erro, ''),
           CASE WHEN erro IS NULL OR erro = '' THEN '' ELSE '\n' END,
           '[AUTO-LIMPEZA] Lock expirado; tarefa voltou para pendente em ',
           DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s')
         )
   WHERE status = 'executando'
     AND lock_adquirido_em IS NOT NULL
     AND lock_adquirido_em < DATE_SUB(NOW(), INTERVAL 30 MINUTE);

  UPDATE fila_automacao
     SET status = 'expirado',
         erro = CONCAT(
           COALESCE(erro, ''),
           CASE WHEN erro IS NULL OR erro = '' THEN '' ELSE '\n' END,
           '[AUTO-LIMPEZA] Tarefa pendente expirada automaticamente em ',
           DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s')
         )
   WHERE status = 'pendente'
     AND data_solicitacao < DATE_SUB(NOW(), INTERVAL 7 DAY);

  DELETE FROM fila_automacao
   WHERE status IN ('concluido', 'erro', 'expirado')
     AND data_solicitacao < DATE_SUB(NOW(), INTERVAL 30 DAY);
END$$

DELIMITER ;

DROP EVENT IF EXISTS evt_limpar_fila_automacao_antiga;

DELIMITER $$

CREATE EVENT evt_limpar_fila_automacao_antiga
ON SCHEDULE EVERY 1 HOUR
STARTS CURRENT_TIMESTAMP + INTERVAL 5 MINUTE
DO
BEGIN
  CALL sp_limpar_fila_automacao_antiga();
END$$

DELIMITER ;

-- Executa uma limpeza imediata no momento da migração.
CALL sp_limpar_fila_automacao_antiga();

-- Conferência final.
SELECT
  id,
  usuario_solicitante_id,
  usuario_solicitante_nome,
  maquina_destino,
  tipo_automacao,
  grupo_escolar,
  status,
  lock_owner,
  lock_adquirido_em,
  data_solicitacao,
  iniciado_em,
  concluido_em,
  tentativas,
  erro
FROM fila_automacao
ORDER BY id DESC
LIMIT 50;
