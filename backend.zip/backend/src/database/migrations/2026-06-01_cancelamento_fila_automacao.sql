USE Sistema_Chamada;

-- Permite cancelamento seguro de tarefas antes de o robô local capturá-las.
ALTER TABLE fila_automacao
  MODIFY status ENUM('pendente', 'executando', 'concluido', 'erro', 'expirado', 'cancelado') NOT NULL DEFAULT 'pendente';

-- Garante que registros cancelados antigos também sejam removidos pela rotina de limpeza histórica.
DROP PROCEDURE IF EXISTS sp_limpar_fila_automacao_antiga;

DELIMITER $$
CREATE PROCEDURE sp_limpar_fila_automacao_antiga()
BEGIN
  UPDATE fila_automacao
     SET status = 'expirado',
         erro = COALESCE(erro, 'Tarefa expirada automaticamente por ficar pendente por mais de 7 dias.')
   WHERE status = 'pendente'
     AND data_solicitacao < DATE_SUB(NOW(), INTERVAL 7 DAY);

  UPDATE fila_automacao
     SET status = 'pendente',
         lock_owner = NULL,
         lock_adquirido_em = NULL,
         iniciado_em = NULL,
         erro = COALESCE(erro, 'Lock liberado automaticamente por inatividade superior a 30 minutos.')
   WHERE status = 'executando'
     AND lock_adquirido_em < DATE_SUB(NOW(), INTERVAL 30 MINUTE);

  DELETE FROM fila_automacao
   WHERE status IN ('concluido', 'erro', 'expirado', 'cancelado')
     AND data_solicitacao < DATE_SUB(NOW(), INTERVAL 30 DAY);
END$$
DELIMITER ;
