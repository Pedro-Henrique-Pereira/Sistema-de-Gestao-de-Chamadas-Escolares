USE Sistema_Chamada;

-- ============================================================
-- Migração segura da fila_automacao para lock por máquina.
-- Regra:
--   Pedagogas      -> máquinas 1 e 2
--   Administração -> máquinas 3, 4 e 5
-- ============================================================

CREATE TABLE IF NOT EXISTS fila_automacao (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_solicitante_id INT NULL,
  usuario_solicitante_nome VARCHAR(100) NULL,
  maquina_destino TINYINT NOT NULL DEFAULT 1,
  status ENUM('pendente', 'executando', 'concluido', 'erro', 'expirado', 'cancelado') NOT NULL DEFAULT 'pendente',
  lock_owner VARCHAR(100) NULL,
  lock_adquirido_em DATETIME NULL,
  data_solicitacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  iniciado_em DATETIME NULL,
  concluido_em DATETIME NULL,
  tentativas INT NOT NULL DEFAULT 0,
  erro TEXT NULL,
  INDEX idx_fila_captura_segura (status, maquina_destino, data_solicitacao),
  INDEX idx_fila_usuario (usuario_solicitante_id),
  INDEX idx_fila_lock (lock_owner, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE fila_automacao
  MODIFY status ENUM('pendente', 'executando', 'concluido', 'erro', 'expirado', 'cancelado')
  NOT NULL DEFAULT 'pendente';

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN usuario_solicitante_id INT NULL AFTER id',
    'SELECT "usuario_solicitante_id já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'usuario_solicitante_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN usuario_solicitante_nome VARCHAR(100) NULL AFTER usuario_solicitante_id',
    'SELECT "usuario_solicitante_nome já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'usuario_solicitante_nome'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN maquina_destino TINYINT NOT NULL DEFAULT 1 AFTER usuario_solicitante_nome',
    'SELECT "maquina_destino já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'maquina_destino'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN lock_owner VARCHAR(100) NULL AFTER status',
    'SELECT "lock_owner já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'lock_owner'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN lock_adquirido_em DATETIME NULL AFTER lock_owner',
    'SELECT "lock_adquirido_em já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'lock_adquirido_em'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN iniciado_em DATETIME NULL AFTER data_solicitacao',
    'SELECT "iniciado_em já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'iniciado_em'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN concluido_em DATETIME NULL AFTER iniciado_em',
    'SELECT "concluido_em já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'concluido_em'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN tentativas INT NOT NULL DEFAULT 0 AFTER concluido_em',
    'SELECT "tentativas já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'tentativas'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD COLUMN erro TEXT NULL AFTER tentativas',
    'SELECT "erro já existe"'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND COLUMN_NAME = 'erro'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Normaliza linhas antigas que não possuem destino.
UPDATE fila_automacao
SET maquina_destino = 1
WHERE maquina_destino IS NULL OR maquina_destino NOT BETWEEN 1 AND 5;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD INDEX idx_fila_captura_segura (status, maquina_destino, data_solicitacao)',
    'SELECT "idx_fila_captura_segura já existe"'
  )
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND INDEX_NAME = 'idx_fila_captura_segura'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD INDEX idx_fila_usuario (usuario_solicitante_id)',
    'SELECT "idx_fila_usuario já existe"'
  )
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND INDEX_NAME = 'idx_fila_usuario'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE fila_automacao ADD INDEX idx_fila_lock (lock_owner, status)',
    'SELECT "idx_fila_lock já existe"'
  )
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'fila_automacao'
    AND INDEX_NAME = 'idx_fila_lock'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Se uma máquina desligar no meio, esta rotina libera tarefas travadas há mais de 30 minutos.
-- Pode ser executada manualmente ou agendada no MySQL/Event Scheduler.
UPDATE fila_automacao
SET status = 'pendente',
    lock_owner = NULL,
    lock_adquirido_em = NULL,
    iniciado_em = NULL
WHERE status = 'executando'
  AND lock_adquirido_em < DATE_SUB(NOW(), INTERVAL 30 MINUTE);
