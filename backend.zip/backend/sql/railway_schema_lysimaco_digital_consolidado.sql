-- ============================================================
-- LYSIMACO DIGITAL / SISTEMA DE CHAMADAS
-- Schema consolidado para Railway MySQL
-- Gerado a partir do backend Node/Express e da automação Python anexados.
--
-- IMPORTANTE RAILWAY:
-- - Não usa CREATE DATABASE.
-- - Não usa USE.
-- - Execute dentro do schema/database fornecido pelo Railway.
-- - Recomendado para MySQL 8.x.
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;

-- ============================================================
-- 1. USUÁRIOS / EQUIPE
-- Perfis usados pelo código: professor, pedagoga, administracao.
-- Inclui preferências manuais de máquina, sem balanceamento automático.
-- ============================================================

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  senha_hash VARCHAR(255) NOT NULL,
  tipo ENUM('professor', 'pedagoga', 'administracao') NOT NULL,
  ativo BOOLEAN NOT NULL DEFAULT TRUE,

  -- Chamadas/faltas: pedagoga usa 1/2; administracao usa 3/4/5.
  -- A validação forte por perfil fica no backend para não quebrar edições de cargo.
  maquina_padrao_chamadas TINYINT NULL,

  -- Mensagens em grupos do administrador: somente 3/4/5 no backend.
  maquina_padrao_mensagens TINYINT NULL,

  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uk_usuarios_email (email),
  KEY idx_usuarios_email (email),
  KEY idx_usuarios_tipo_ativo (tipo, ativo),
  KEY idx_usuarios_maquina_padrao_chamadas (maquina_padrao_chamadas),
  KEY idx_usuarios_maquina_padrao_mensagens (maquina_padrao_mensagens),

  CONSTRAINT chk_usuarios_maquina_padrao_chamadas
    CHECK (maquina_padrao_chamadas IS NULL OR maquina_padrao_chamadas BETWEEN 1 AND 5),

  CONSTRAINT chk_usuarios_maquina_padrao_mensagens
    CHECK (maquina_padrao_mensagens IS NULL OR maquina_padrao_mensagens IN (3, 4, 5))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- 2. SESSÕES ATIVAS
-- Obrigatória para a correção P0 de sessão única server-side.
-- O backend valida o jti do JWT nesta tabela.
-- ============================================================

CREATE TABLE IF NOT EXISTS sessoes_ativas (
  id CHAR(36) NOT NULL,
  usuario_id INT NOT NULL,
  token_id CHAR(36) NOT NULL,
  dispositivo_info TEXT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expira_em DATETIME NOT NULL,

  PRIMARY KEY (id),
  UNIQUE KEY uk_sessoes_ativas_token_id (token_id),
  KEY idx_sessoes_ativas_usuario_token (usuario_id, token_id),
  KEY idx_sessoes_ativas_expira_em (expira_em),

  CONSTRAINT fk_sessoes_ativas_usuario
    FOREIGN KEY (usuario_id)
    REFERENCES usuarios(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- 3. TURMAS
-- Versão final sem grupo_escolar: a tela de mensagens usa grupos reais do WhatsApp.
-- ============================================================

CREATE TABLE IF NOT EXISTS turmas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(50) NOT NULL,
  criada_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizada_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uk_turmas_nome (nome),
  KEY idx_turmas_nome (nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- 4. ALUNOS
-- ============================================================

CREATE TABLE IF NOT EXISTS alunos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(150) NOT NULL,
  idade INT NULL,
  sexo ENUM('masculino', 'feminino', 'outro', 'nao_informado') NULL,
  turma_id INT NULL,
  ativo BOOLEAN NOT NULL DEFAULT TRUE,

  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_alunos_nome (nome),
  KEY idx_alunos_turma (turma_id),
  KEY idx_alunos_turma_ativo (turma_id, ativo),

  CONSTRAINT fk_alunos_turma
    FOREIGN KEY (turma_id)
    REFERENCES turmas(id)
    ON DELETE SET NULL
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- 5. RESPONSÁVEIS
-- Modelo atual do código: responsável pertence diretamente a um aluno.
-- ============================================================

CREATE TABLE IF NOT EXISTS responsaveis (
  id INT AUTO_INCREMENT PRIMARY KEY,
  aluno_id INT NOT NULL,
  nome VARCHAR(150) NOT NULL,
  parentesco VARCHAR(50) NOT NULL DEFAULT 'Responsável',
  contato VARCHAR(30) NOT NULL,
  email VARCHAR(150) NULL,
  ativo BOOLEAN NOT NULL DEFAULT TRUE,

  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_responsaveis_aluno (aluno_id),
  KEY idx_responsaveis_contato (contato),
  KEY idx_responsaveis_nome (nome),

  CONSTRAINT fk_responsaveis_aluno
    FOREIGN KEY (aluno_id)
    REFERENCES alunos(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- 6. CHAMADAS DIÁRIAS TEMPORÁRIAS
-- Chamadas abertas antes da confirmação oficial pela pedagoga/admin.
-- Regra: uma chamada ativa por turma/data; canceladas liberam nova chamada.
-- ============================================================

CREATE TABLE IF NOT EXISTS chamadas_diarias (
  id INT AUTO_INCREMENT PRIMARY KEY,

  professor_id INT NOT NULL,
  professor_nome VARCHAR(100) NOT NULL,

  turma_id INT NULL,
  turma_nome VARCHAR(50) NOT NULL,

  materia VARCHAR(100) NOT NULL,

  data_chamada DATE NOT NULL,
  horario_chamada TIME NOT NULL DEFAULT (CURRENT_TIME),

  alunos JSON NOT NULL,

  total_presentes INT NOT NULL DEFAULT 0,
  total_ausentes INT NOT NULL DEFAULT 0,

  atraso_processado BOOLEAN NOT NULL DEFAULT FALSE,

  status ENUM('pendente', 'confirmada', 'cancelada') NOT NULL DEFAULT 'pendente',

  chamada_ativa_key TINYINT
    GENERATED ALWAYS AS (
      CASE WHEN status <> 'cancelada' THEN 1 ELSE NULL END
    ) STORED,

  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uk_chamada_turma_data_ativa (turma_id, data_chamada, chamada_ativa_key),

  KEY idx_chamadas_data_materia (data_chamada, materia),
  KEY idx_chamadas_turma_data_materia (turma_id, data_chamada, materia),
  KEY idx_chamadas_professor_data (professor_id, data_chamada),
  KEY idx_chamadas_status (status),
  KEY idx_chamadas_turma_data_status (turma_id, data_chamada, status),

  CONSTRAINT fk_chamadas_professor
    FOREIGN KEY (professor_id)
    REFERENCES usuarios(id)
    ON DELETE RESTRICT
    ON UPDATE CASCADE,

  CONSTRAINT fk_chamadas_turma
    FOREIGN KEY (turma_id)
    REFERENCES turmas(id)
    ON DELETE SET NULL
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- 7. CHAMADAS CONFIRMADAS / HISTÓRICO OFICIAL
-- ============================================================

CREATE TABLE IF NOT EXISTS registros_chamadas_confirmadas (
  id INT AUTO_INCREMENT PRIMARY KEY,

  chamada_diaria_id_origem INT NULL,

  professor_id INT NOT NULL,
  professor_nome VARCHAR(100) NOT NULL,

  pedagoga_id INT NOT NULL,
  pedagoga_nome VARCHAR(100) NOT NULL,

  turma_id INT NULL,
  turma_nome VARCHAR(50) NOT NULL,

  materia VARCHAR(100) NOT NULL,

  data_chamada DATE NOT NULL,
  horario_chamada TIME NOT NULL,

  total_presentes INT NOT NULL DEFAULT 0,
  total_ausentes INT NOT NULL DEFAULT 0,
  total_justificados INT NOT NULL DEFAULT 0,
  total_atrasos INT NOT NULL DEFAULT 0,

  observacao TEXT NULL,

  confirmado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uk_reg_chamada_origem (chamada_diaria_id_origem),

  KEY idx_reg_chamada_data (data_chamada),
  KEY idx_reg_chamada_turma_data (turma_id, data_chamada),
  KEY idx_rcc_turma_data (turma_id, data_chamada),
  KEY idx_reg_chamada_professor_data (professor_id, data_chamada),
  KEY idx_reg_chamada_pedagoga_data (pedagoga_id, data_chamada),
  KEY idx_reg_chamada_materia (materia),
  KEY idx_reg_origem (chamada_diaria_id_origem),

  CONSTRAINT fk_reg_chamada_origem
    FOREIGN KEY (chamada_diaria_id_origem)
    REFERENCES chamadas_diarias(id)
    ON DELETE SET NULL
    ON UPDATE CASCADE,

  CONSTRAINT fk_reg_chamada_professor
    FOREIGN KEY (professor_id)
    REFERENCES usuarios(id)
    ON DELETE RESTRICT
    ON UPDATE CASCADE,

  CONSTRAINT fk_reg_chamada_pedagoga
    FOREIGN KEY (pedagoga_id)
    REFERENCES usuarios(id)
    ON DELETE RESTRICT
    ON UPDATE CASCADE,

  CONSTRAINT fk_reg_chamada_turma
    FOREIGN KEY (turma_id)
    REFERENCES turmas(id)
    ON DELETE SET NULL
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- 8. FREQUÊNCIA POR ALUNO
-- Base dos relatórios e da automação de faltas confirmadas.
-- ============================================================

CREATE TABLE IF NOT EXISTS registros_frequencia_alunos (
  id INT AUTO_INCREMENT PRIMARY KEY,

  registro_chamada_id INT NOT NULL,

  aluno_id INT NOT NULL,
  aluno_nome VARCHAR(150) NOT NULL,

  turma_id INT NULL,
  turma_nome VARCHAR(50) NOT NULL,

  materia VARCHAR(100) NOT NULL,
  data_chamada DATE NOT NULL,

  status ENUM('presente', 'ausente', 'justificado') NOT NULL,
  atrasado BOOLEAN NOT NULL DEFAULT FALSE,

  horario_registro_atraso TIME NULL,
  atraso_registrado_em DATETIME NULL,

  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uk_freq_aluno_chamada (registro_chamada_id, aluno_id),

  KEY idx_freq_aluno_data (aluno_id, data_chamada),
  KEY idx_freq_turma_data (turma_id, data_chamada),
  KEY idx_freq_status (status),
  KEY idx_freq_materia (materia),
  KEY idx_freq_reg_status_atrasado (registro_chamada_id, status, atrasado),

  -- Índices de performance usados por relatórios e auditorias.
  KEY idx_rfa_data_registro (data_chamada, registro_chamada_id),
  KEY idx_rfa_turma_data (turma_id, data_chamada),
  KEY idx_rfa_aluno_data (aluno_id, data_chamada),
  KEY idx_freq_relatorios_data_turma (data_chamada, turma_id, materia),
  KEY idx_freq_relatorios_status_atraso (status, atrasado, data_chamada),
  KEY idx_rfa_automacao_faltas_dia (data_chamada, status, aluno_id),

  CONSTRAINT fk_freq_registro_chamada
    FOREIGN KEY (registro_chamada_id)
    REFERENCES registros_chamadas_confirmadas(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,

  CONSTRAINT fk_freq_aluno
    FOREIGN KEY (aluno_id)
    REFERENCES alunos(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,

  CONSTRAINT fk_freq_turma
    FOREIGN KEY (turma_id)
    REFERENCES turmas(id)
    ON DELETE SET NULL
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- 9. JUSTIFICATIVAS DE FREQUÊNCIA
-- ============================================================

CREATE TABLE IF NOT EXISTS justificativas_frequencia (
  id INT AUTO_INCREMENT PRIMARY KEY,

  frequencia_aluno_id INT NOT NULL,
  aluno_id INT NOT NULL,
  registro_chamada_id INT NOT NULL,

  motivo TEXT NOT NULL,
  anexos JSON NULL,

  registrada_por_id INT NOT NULL,
  registrada_por_nome VARCHAR(100) NOT NULL,

  registrada_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_just_aluno (aluno_id),
  KEY idx_just_chamada (registro_chamada_id),
  KEY idx_jf_aluno_freq (aluno_id, frequencia_aluno_id),
  KEY idx_just_relatorios_aluno_data (aluno_id, frequencia_aluno_id),
  KEY idx_just_registrada_em (registrada_em),

  CONSTRAINT fk_just_freq
    FOREIGN KEY (frequencia_aluno_id)
    REFERENCES registros_frequencia_alunos(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,

  CONSTRAINT fk_just_aluno
    FOREIGN KEY (aluno_id)
    REFERENCES alunos(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,

  CONSTRAINT fk_just_chamada
    FOREIGN KEY (registro_chamada_id)
    REFERENCES registros_chamadas_confirmadas(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,

  CONSTRAINT fk_just_usuario
    FOREIGN KEY (registrada_por_id)
    REFERENCES usuarios(id)
    ON DELETE RESTRICT
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- 10. CONFIGURAÇÕES DA ESCOLA
-- ============================================================

CREATE TABLE IF NOT EXISTS configuracoes_escola (
  id INT PRIMARY KEY DEFAULT 1,

  horario_limite_atraso TIME NOT NULL DEFAULT '07:45:00',
  tempo_maximo_justificativas_meses TINYINT NOT NULL DEFAULT 1,

  atualizado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  CONSTRAINT chk_configuracoes_escola_id
    CHECK (id = 1),

  CONSTRAINT chk_tempo_justificativas_meses
    CHECK (tempo_maximo_justificativas_meses BETWEEN 1 AND 3)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO configuracoes_escola (
  id,
  horario_limite_atraso,
  tempo_maximo_justificativas_meses
)
VALUES (1, '07:45:00', 1)
ON DUPLICATE KEY UPDATE
  horario_limite_atraso = VALUES(horario_limite_atraso),
  tempo_maximo_justificativas_meses = VALUES(tempo_maximo_justificativas_meses);


-- ============================================================
-- 11. MENSAGEM PADRÃO DA AUTOMAÇÃO WHATSAPP
-- ============================================================

CREATE TABLE IF NOT EXISTS config_mensagem_whatsapp (
  id TINYINT PRIMARY KEY DEFAULT 1,
  texto TEXT NOT NULL,
  atualizado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  CONSTRAINT chk_config_mensagem_whatsapp_id
    CHECK (id = 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO config_mensagem_whatsapp (id, texto)
VALUES (
  1,
  'Olá, tudo bem? Identificamos uma falta registrada hoje. Poderia informar o motivo da ausência?'
)
ON DUPLICATE KEY UPDATE
  texto = texto;


-- ============================================================
-- 12. CONTROLE DE ENVIOS DIÁRIOS
-- Evita duplicidade de mensagem de falta para o mesmo aluno no mesmo dia.
-- ============================================================

CREATE TABLE IF NOT EXISTS controle_envios_diarios (
  aluno_id INT NOT NULL,
  data_envio DATE NOT NULL,

  status ENUM('pendente', 'enviado', 'erro') NOT NULL DEFAULT 'pendente',

  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (aluno_id, data_envio),
  KEY idx_controle_data_status (data_envio, status),

  CONSTRAINT fk_controle_envios_aluno
    FOREIGN KEY (aluno_id)
    REFERENCES alunos(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- 13. GRUPOS REAIS DO WHATSAPP
-- Usado pela tela de mensagens do administrador.
-- ============================================================

CREATE TABLE IF NOT EXISTS grupos_whatsapp (
  id INT AUTO_INCREMENT PRIMARY KEY,

  nome_grupo VARCHAR(150) NOT NULL,
  ativo BOOLEAN NOT NULL DEFAULT TRUE,

  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uk_grupos_whatsapp_nome (nome_grupo),
  KEY idx_grupos_whatsapp_ativo_nome (ativo, nome_grupo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- 14. FILA DA AUTOMAÇÃO LOCAL PYTHON / WHATSAPP
-- Compatível com SELECT ... FOR UPDATE SKIP LOCKED.
-- Sem escolha automática de máquina, sem redistribuição e sem fallback.
-- ============================================================

CREATE TABLE IF NOT EXISTS fila_automacao (
  id INT AUTO_INCREMENT PRIMARY KEY,

  usuario_solicitante_id INT NULL,
  usuario_solicitante_nome VARCHAR(100) NULL,

  maquina_destino TINYINT NOT NULL,

  tipo_automacao ENUM('faltas', 'mensagem_grupo') NOT NULL DEFAULT 'faltas',

  mensagem TEXT NULL,
  payload JSON NULL,

  status ENUM(
    'pendente',
    'executando',
    'concluido',
    'erro',
    'expirado',
    'cancelado'
  ) NOT NULL DEFAULT 'pendente',

  lock_owner VARCHAR(100) NULL,
  lock_adquirido_em DATETIME NULL,

  data_solicitacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  iniciado_em DATETIME NULL,
  concluido_em DATETIME NULL,

  tentativas INT NOT NULL DEFAULT 0,
  erro TEXT NULL,

  KEY idx_fila_automacao_status_data (status, data_solicitacao),
  KEY idx_fila_captura_segura (status, maquina_destino, data_solicitacao),
  KEY idx_fila_tipo_status_maquina (tipo_automacao, status, maquina_destino, data_solicitacao),
  KEY idx_fila_mensagens_grupo (tipo_automacao, status, maquina_destino, data_solicitacao),
  KEY idx_fila_usuario (usuario_solicitante_id),
  KEY idx_fila_lock (lock_owner, status),

  CONSTRAINT fk_fila_usuario_solicitante
    FOREIGN KEY (usuario_solicitante_id)
    REFERENCES usuarios(id)
    ON DELETE SET NULL
    ON UPDATE CASCADE,

  CONSTRAINT chk_fila_maquina_destino
    CHECK (maquina_destino BETWEEN 1 AND 5),

  CONSTRAINT chk_fila_tentativas
    CHECK (tentativas >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- 15. LIMPEZAS SEGURAS INICIAIS
-- Não apaga dados recentes. Apenas expira/corrige estados antigos.
-- ============================================================

DELETE FROM sessoes_ativas WHERE expira_em <= NOW();
DELETE FROM controle_envios_diarios WHERE data_envio < CURDATE();

UPDATE fila_automacao
   SET status = 'expirado',
       erro = COALESCE(erro, 'Tarefa expirada automaticamente por ficar pendente por mais de 7 dias.')
 WHERE status = 'pendente'
   AND data_solicitacao < DATE_SUB(NOW(), INTERVAL 7 DAY);

UPDATE fila_automacao
   SET status = 'pendente',
       lock_owner = NULL,
       lock_adquirido_em = NULL,
       iniciado_em = NULL,
       erro = COALESCE(erro, 'Lock liberado automaticamente por inatividade superior a 30 minutos.')
 WHERE status = 'executando'
   AND lock_adquirido_em < DATE_SUB(NOW(), INTERVAL 30 MINUTE);

-- ============================================================
-- 16. OBSERVAÇÃO SOBRE LIMPEZA PROGRAMADA
-- O backend já possui rotina manual/serviço de limpeza.
-- Para Railway, esta versão evita CREATE EVENT/DELIMITER para manter execução direta.
-- ============================================================

-- ============================================================
-- 17. CONFERÊNCIA FINAL
-- ============================================================

SHOW TABLES;
SHOW INDEX FROM usuarios;
SHOW INDEX FROM sessoes_ativas;
SHOW INDEX FROM registros_frequencia_alunos;
SHOW INDEX FROM justificativas_frequencia;
SHOW INDEX FROM registros_chamadas_confirmadas;
SHOW INDEX FROM fila_automacao;
